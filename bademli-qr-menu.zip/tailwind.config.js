/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        cream: '#F4E9D8',
        brown: { deep: '#3A2118', choc: '#5A2E20' },
        burgundy: '#8F1D24',
        beige: '#D8C2A6',
        warm: '#FFF9F1',
      },
      fontFamily: {
        serif: ['"Playfair Display"', 'Georgia', 'serif'],
        sans: ['"Jost"', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        card: '0 10px 30px -12px rgba(58,33,24,.28)',
      },
    },
  },
  plugins: [],
}

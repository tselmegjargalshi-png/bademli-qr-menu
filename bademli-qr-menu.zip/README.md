# Bademli Pasta & Cafe — QR Dijital Menü (DEMO)

BASIC MENU concept. React + TypeScript + Tailwind (Vite).
All prices and menu items other than the names taken from the Instagram posts are hypothetical demo content.

    npm install
    npm run dev      # http://localhost:5173  (open in a 390–430px mobile viewport)
    npm run build

Menu data: `src/data/menu.ts` · Product photos: `public/images/products/`

export type CategoryId =
  | 'cok-sevilenler'
  | 'cheesecake'
  | 'tatli-pasta'
  | 'ozel'
  | 'firin'
  | 'kahve'
  | 'soguk'
  | 'sicak'

export interface Category {
  id: CategoryId
  label: string
  short: string
  blurb: string
}

export interface Product {
  id: string
  name: string
  description: string
  /** Hypothetical DEMO price in Turkish lira */
  price: number
  category: Exclude<CategoryId, 'cok-sevilenler'>
  /** File name inside /images/products (omit for list-style items) */
  image?: string
  tag?: string
  featured?: boolean
}

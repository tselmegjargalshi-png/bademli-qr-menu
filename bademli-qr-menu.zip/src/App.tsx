import { useCallback, useEffect, useMemo, useState } from 'react'
import Header from './components/Header'
import Hero from './components/Hero'
import CategoryNav from './components/CategoryNav'
import FeaturedProducts from './components/FeaturedProducts'
import MenuCategory from './components/MenuCategory'
import QRSection from './components/QRSection'
import ContactSection from './components/ContactSection'
import Footer from './components/Footer'
import BackToTop from './components/BackToTop'
import { categories, featuredProducts, products } from './data/menu'
import type { CategoryId } from './types'

export default function App() {
  const [active, setActive] = useState<CategoryId>('cok-sevilenler')

  const sections = useMemo(() => categories.filter((c) => c.id !== 'cok-sevilenler'), [])

  const scrollTo = useCallback((id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }, [])

  // scroll-spy: highlight the category currently under the sticky bar
  useEffect(() => {
    const ids = categories.map((c) => c.id)
    const onScroll = () => {
      let current: CategoryId = ids[0]
      for (const id of ids) {
        const el = document.getElementById(id)
        if (el && el.getBoundingClientRect().top <= 140) current = id
      }
      setActive(current)
    }
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <>
      <Header />
      <main>
        <Hero onExplore={() => scrollTo('cok-sevilenler')} />
        <CategoryNav categories={categories} active={active} onSelect={scrollTo as (id: CategoryId) => void} />
        <FeaturedProducts items={featuredProducts} />
        {sections.map((c) => (
          <MenuCategory key={c.id} category={c} items={products.filter((p) => p.category === c.id)} />
        ))}
        <QRSection />
        <ContactSection />
      </main>
      <Footer />
      <BackToTop />
    </>
  )
}

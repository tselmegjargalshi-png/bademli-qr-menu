import type { Category, Product } from '../types'

export const categories: Category[] = [
  { id: 'cok-sevilenler', label: 'Çok Sevilenler', short: 'Çok Sevilenler', blurb: 'Misafirlerimizin en çok tercih ettiği lezzetler.' },
  { id: 'cheesecake', label: 'Cheesecake', short: 'Cheesecake', blurb: 'Kremamsı dokular, taze soslar.' },
  { id: 'tatli-pasta', label: 'Tatlı & Pasta', short: 'Tatlı & Pasta', blurb: 'Günlük hazırlanan pasta ve tatlılar.' },
  { id: 'ozel', label: 'Özel Ürünler', short: 'Özel', blurb: 'Bademli imzası taşıyan özel tatlar.' },
  { id: 'firin', label: 'Fırın & Taze', short: 'Fırın', blurb: 'Güne taze bir başlangıç için günlük fırın ürünleri.' },
  { id: 'kahve', label: 'Kahveler', short: 'Kahve', blurb: 'Taze çekilmiş kahve çekirdekleriyle.' },
  { id: 'soguk', label: 'Soğuk İçecekler', short: 'Soğuk İçecekler', blurb: 'Serinleten, ferah seçenekler.' },
  { id: 'sicak', label: 'Sıcak İçecekler', short: 'Sıcak İçecekler', blurb: 'Keyifli bir mola için.' },
]

// ALL PRICES ARE HYPOTHETICAL DEMO PRICES — presentation only.
export const products: Product[] = [
  // — Cheesecake —
  { id: 'cilekli-cup', name: 'Çilekli Cup', description: 'Taze çilek, hafif krema ve çikolatanın mükemmel uyumu.', price: 320, category: 'tatli-pasta', image: 'cilekli-cup.jpg', tag: 'Çok Satan', featured: true },
  { id: 'frambuazli-cheesecake', name: 'Frambuazlı Cheesecake', description: 'Taze frambuaz sosu ve kremamsı cheesecake lezzetiyle dengeli ve ferah bir tat.', price: 340, category: 'cheesecake', image: 'frambuazli-cheesecake.jpg', tag: 'Çok Satan', featured: true },
  { id: 'lotuslu-cheesecake', name: 'Lotuslu Cheesecake', description: 'Lotus bisküvisi, krema ve karamel lezzetinin mükemmel uyumu.', price: 340, category: 'cheesecake', image: 'lotuslu-cheesecake.jpg', tag: 'Çok Satan', featured: true },
  { id: 'limonlu-cheesecake', name: 'Limonlu Cheesecake', description: 'Ferahlatan limon lezzeti, kremalı cheesecake dokusuyla buluşuyor.', price: 330, category: 'cheesecake', image: 'limonlu-cheesecake.jpg', featured: true },
  { id: 'san-sebastian', name: 'San Sebastian Cheesecake', description: 'Dışı hafif yanık, içi kremamsı; çikolata sosuyla servis edilir.', price: 350, category: 'cheesecake', image: 'san-sebastian.jpg', featured: true },
  { id: 'cikolatali-cheesecake', name: 'Çikolatalı Cheesecake', description: 'Yoğun bitter çikolata ve yumuşacık cheesecake kreması.', price: 340, category: 'cheesecake' },
  { id: 'bogurtlenli-cheesecake', name: 'Böğürtlenli Cheesecake', description: 'Böğürtlen sosu ile hafif ekşi, dengeli bir lezzet.', price: 340, category: 'cheesecake' },

  // — Tatlı & Pasta —
  { id: 'cikolatali-findikli-pasta', name: 'Çikolatalı Fındıklı Pasta', description: 'Yoğun çikolata, kremsi katmanlar ve kavrulmuş fındık dokusunun zengin buluşması.', price: 360, category: 'tatli-pasta', image: 'cikolatali-findikli-pasta.jpg', tag: 'Çok Satan', featured: true },
  { id: 'tiramisu', name: 'Tiramisu', description: 'Kahve aroması, mascarpone kreması ve kakao ile klasikleşen İtalyan lezzeti.', price: 310, category: 'tatli-pasta', image: 'tiramisu.jpg', featured: true },
  { id: 'malaga', name: 'Malaga', description: 'Çikolata, fındık ve özel kremasıyla klasikleşen bir lezzet.', price: 290, category: 'tatli-pasta', image: 'malaga.jpg' },
  { id: 'supangle', name: 'Supangle', description: 'Yoğun çikolata lezzeti, ipeksi kıvamıyla efsane bir tat.', price: 280, category: 'tatli-pasta', image: 'supangle.jpg' },
  { id: 'red-velvet', name: 'Red Velvet', description: 'Kadife dokulu kırmızı kek, krem peynir kreması ile.', price: 330, category: 'tatli-pasta' },
  { id: 'fistikli-pasta', name: 'Fıstıklı Pasta', description: 'Antep fıstığı kreması ve yumuşak kek katmanları.', price: 370, category: 'tatli-pasta' },
  { id: 'brownie', name: 'Brownie', description: 'Sıcak servis edilen yoğun çikolatalı brownie.', price: 220, category: 'tatli-pasta' },
  { id: 'cookie', name: 'Cookie', description: 'Çikolata parçacıklı, dışı çıtır içi yumuşak.', price: 150, category: 'tatli-pasta' },
  { id: 'profiterol', name: 'Profiterol', description: 'Hafif krema dolgulu, bol çikolata soslu.', price: 260, category: 'tatli-pasta' },
  { id: 'waffle', name: 'Waffle', description: 'Taze meyve, çikolata sosu ve dondurma ile.', price: 340, category: 'tatli-pasta' },
  { id: 'sufle', name: 'Sufle', description: 'Akışkan çikolata kalpli, sıcak servis edilen sufle.', price: 280, category: 'tatli-pasta' },

  // — Özel Ürünler —
  { id: 'dubai-cikolatali-magnolya', name: 'Dubai Çikolatalı Magnolya', description: 'Kadayıf, Antep fıstığı ve çikolatanın eşsiz uyumu.', price: 330, category: 'ozel', image: 'dubai-cikolatali-magnolya.jpg', tag: 'Özel', featured: true },
  { id: 'lotus-magnolya', name: 'Lotus Magnolya', description: 'Krema, Lotus bisküvisi ve her kaşıkta gelen karamelize lezzet.', price: 270, category: 'ozel', image: 'lotus-magnolya.jpg' },
  { id: 'oreolu-magnolya', name: 'Oreolu Magnolya', description: 'Kakaolu bisküvi, kremalı magnolya ve oreo lezzetiyle eşsiz bir uyum.', price: 270, category: 'ozel', image: 'oreolu-magnolya.jpg' },
  { id: 'balkabakli-magnolya', name: 'Balkabaklı Magnolya', description: 'Sonbaharın en tatlı hali: balkabağı, ceviz ve ipeksi krema.', price: 280, category: 'ozel', image: 'balkabakli-magnolya.jpg' },
  { id: 'frambuazli-trilece', name: 'Frambuazlı Trileçe', description: 'Yumuşacık keki, hafif sütü ve taze frambuaz sosuyla ferah bir lezzet.', price: 270, category: 'ozel', image: 'frambuazli-trilece.jpg' },
  { id: 'soguk-baklava', name: 'Soğuk Baklava', description: 'Bol sütle ıslatılmış, incecik katmanları ve fıstıkla tamamlanan serinleten lezzet.', price: 300, category: 'ozel', image: 'soguk-baklava.jpg' },
  { id: 'firin-sutlac', name: 'Fırın Sütlaç', description: 'Geleneksel lezzet, fırında nar gibi kızarmış sütlaç keyfi.', price: 220, category: 'ozel', image: 'firin-sutlac.jpg' },

  { id: 'incir-uyutmasi', name: 'İncir Uyutması', description: 'Kuru incirin doğal tatlılığı, sütün yumuşak dokusuyla buluşuyor.', price: 240, category: 'ozel' },

  // — Fırın & Taze —
  { id: 'simit', name: 'Simit', description: 'Taze fırından, susamlı ve çıtır.', price: 60, category: 'firin' },
  { id: 'pogaca', name: 'Poğaça', description: 'Günlük hazırlanan, yumuşacık hamurlu poğaça.', price: 75, category: 'firin' },
  { id: 'borek', name: 'Börek', description: 'Kat kat açılmış hamuru ve sıcak servisiyle fırın böreği.', price: 150, category: 'firin' },

  // — Kahveler —
  { id: 'espresso', name: 'Espresso', description: 'Yoğun gövdeli, tek shot klasik espresso.', price: 120, category: 'kahve' },
  { id: 'americano', name: 'Americano', description: 'Espresso ve sıcak su ile hafif içimli kahve.', price: 140, category: 'kahve' },
  { id: 'cappuccino', name: 'Cappuccino', description: 'Espresso, buharlanmış süt ve kadifemsi süt köpüğü.', price: 165, category: 'kahve' },
  { id: 'latte', name: 'Latte', description: 'Yumuşak içimli, bol sütlü espresso.', price: 170, category: 'kahve' },
  { id: 'flat-white', name: 'Flat White', description: 'Çift shot espresso ve ipeksi süt dokusu.', price: 175, category: 'kahve' },
  { id: 'mocha', name: 'Mocha', description: 'Espresso, çikolata sosu ve süt buluşması.', price: 185, category: 'kahve' },
  { id: 'turk-kahvesi', name: 'Türk Kahvesi', description: 'Közde pişmiş geleneksel kahve, lokum ile.', price: 130, category: 'kahve' },

  // — Soğuk İçecekler —
  { id: 'ice-latte', name: 'Ice Latte', description: 'Buz üzerinde süt ve espresso.', price: 180, category: 'soguk' },
  { id: 'ice-americano', name: 'Ice Americano', description: 'Buzlu, ferah espresso.', price: 155, category: 'soguk' },
  { id: 'frappe', name: 'Frappé', description: 'Kremsi, buzlu kahve içeceği.', price: 190, category: 'soguk' },
  { id: 'limonata', name: 'Taze Limonata', description: 'Taze sıkılmış limon, nane ile.', price: 140, category: 'soguk' },
  { id: 'cilekli-limonata', name: 'Çilekli Limonata', description: 'Çilek püresi ve limonun ferah birleşimi.', price: 160, category: 'soguk' },

  // — Sıcak İçecekler —
  { id: 'turk-cayi', name: 'Türk Çayı', description: 'Demli, ince belli bardakta.', price: 45, category: 'sicak' },
  { id: 'bitki-cayi', name: 'Bitki Çayı', description: 'Ihlamur, adaçayı, kuşburnu seçenekleriyle.', price: 90, category: 'sicak' },
  { id: 'sicak-cikolata', name: 'Sıcak Çikolata', description: 'Yoğun, kremsi, bol çikolatalı.', price: 180, category: 'sicak' },
]

export const featuredProducts = products.filter((p) => p.featured)

export const business = {
  name: 'BADEMLİ',
  sub: 'PASTA & CAFE',
  tagline: 'Fırın • Pasta • Cafe',
  city: 'Milas / Muğla',
  phone: '0501 597 48 48',
  phoneHref: 'tel:+905015974848',
  website: 'www.bademlipastacafe.com',
  websiteHref: 'https://www.bademlipastacafe.com',
  instagramHref: '#', // placeholder
}

export const formatPrice = (n: number) => `₺${n}`

import type { Category, Product } from '../types'
import { ProductCard, ProductRow } from './ProductCard'

interface Props { category: Category; items: Product[] }

export default function MenuCategory({ category, items }: Props) {
  const photo = items.filter((p) => p.image)
  const list = items.filter((p) => !p.image)

  return (
    <section id={category.id} aria-labelledby={`h-${category.id}`} className="scroll-mt-20 pt-10">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <div className="flex items-center gap-4">
          <h2 id={`h-${category.id}`} className="font-serif text-[30px] font-bold text-brown-deep">{category.label}</h2>
          <span className="h-px flex-1 bg-beige" />
        </div>
        <p className="mt-1 text-[15px] text-brown-deep/70">{category.blurb}</p>

        {photo.length > 0 && (
          <div className="mt-5 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {photo.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        )}

        {list.length > 0 && (
          <ul className={`divide-y divide-beige/70 rounded-3xl bg-warm/70 px-5 ring-1 ring-beige/60 ${photo.length ? 'mt-5' : 'mt-5'}`}>
            {list.map((p) => <ProductRow key={p.id} product={p} />)}
          </ul>
        )}
      </div>
    </section>
  )
}

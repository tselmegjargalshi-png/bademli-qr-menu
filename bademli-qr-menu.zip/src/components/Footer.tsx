import { AlmondMark } from './Icons'
import { business } from '../data/menu'

export default function Footer() {
  return (
    <footer className="mt-16 bg-brown-deep px-5 pb-10 pt-12 text-center text-cream">
      <AlmondMark className="mx-auto text-beige" />
      <p className="mt-3 font-serif text-3xl font-semibold tracking-[0.1em]">{business.name}</p>
      <p className="mt-1 text-[10px] tracking-[0.4em] text-beige">{business.sub}</p>
      <p className="mt-6 text-[15px] text-cream/80">{business.city}</p>
      <p className="mt-1 text-[15px] text-cream/80">{business.phone}</p>
      <p className="mt-1 text-[15px] text-cream/80">{business.website}</p>
      <div className="mx-auto my-8 h-px w-20 bg-beige/30" />
      <p className="text-[12px] text-cream/50">Demo içerik — fiyatlar örnek amaçlıdır.</p>
    </footer>
  )
}

import { AlmondMark, MenuIcon } from './Icons'
import { business } from '../data/menu'

export default function Header() {
  return (
    <header className="relative z-10 mx-auto flex max-w-6xl items-center justify-between px-5 pb-2 pt-5 sm:px-8">
      <a href="#top" className="flex items-center gap-2.5 text-brown-deep" aria-label="Bademli Pasta & Cafe">
        <AlmondMark className="text-brown-choc" />
        <span className="leading-none">
          <span className="block font-serif text-[22px] font-semibold tracking-[0.08em]">{business.name}</span>
          <span className="mt-1 block text-[9px] font-medium tracking-[0.34em] text-brown-choc/70">{business.sub}</span>
        </span>
      </a>
      <a
        href="#iletisim"
        className="flex h-11 w-11 items-center justify-center rounded-full border border-beige bg-warm/70 text-brown-deep transition hover:bg-warm"
        aria-label="İletişim bilgilerine git"
      >
        <MenuIcon />
      </a>
    </header>
  )
}

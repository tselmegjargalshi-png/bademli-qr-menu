import { useMemo } from 'react'

const N = 25

/** Deterministic QR-style placeholder (NOT a scannable code). */
function buildGrid(): boolean[][] {
  let s = 20261015
  const rnd = () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296)
  const g = Array.from({ length: N }, () => Array.from({ length: N }, () => rnd() > 0.52))
  const finder = (r: number, c: number) => {
    for (let i = -1; i <= 7; i++)
      for (let j = -1; j <= 7; j++) {
        const rr = r + i, cc = c + j
        if (rr < 0 || cc < 0 || rr >= N || cc >= N) continue
        const edge = i === 0 || i === 6 || j === 0 || j === 6
        const core = i >= 2 && i <= 4 && j >= 2 && j <= 4
        g[rr][cc] = i >= 0 && i <= 6 && j >= 0 && j <= 6 && (edge || core)
      }
  }
  finder(0, 0); finder(0, N - 7); finder(N - 7, 0)
  return g
}

export default function QRSection() {
  const grid = useMemo(buildGrid, [])
  return (
    <section aria-labelledby="h-qr" className="mx-auto mt-14 max-w-6xl px-5 sm:px-8">
      <div className="overflow-hidden rounded-[32px] bg-brown-deep px-6 py-9 text-center text-cream shadow-card sm:flex sm:items-center sm:gap-10 sm:px-12 sm:text-left">
        <div className="mx-auto w-fit shrink-0 rounded-3xl bg-warm p-4 sm:mx-0">
          <svg viewBox={`0 0 ${N} ${N}`} className="h-40 w-40" role="img" aria-label="QR kod örneği">
            {grid.map((row, r) =>
              row.map((on, c) =>
                on ? <rect key={`${r}-${c}`} x={c + 0.06} y={r + 0.06} width={0.88} height={0.88} rx={0.22} fill="#3A2118" /> : null,
              ),
            )}
          </svg>
        </div>
        <div className="mt-6 sm:mt-0">
          <p className="text-[11px] font-medium uppercase tracking-[0.3em] text-beige">QR Menü</p>
          <h2 id="h-qr" className="mt-2 font-serif text-[28px] font-bold leading-tight">Menüyü QR Kod ile Keşfedin</h2>
          <p className="mt-3 max-w-sm text-[15px] leading-relaxed text-cream/75">
            Telefonunuzun kamerasını kodun üzerine tutun; menümüz saniyeler içinde açılsın.
          </p>
        </div>
      </div>
    </section>
  )
}

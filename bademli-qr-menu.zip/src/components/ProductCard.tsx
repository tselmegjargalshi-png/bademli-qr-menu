import type { Product } from '../types'
import { formatPrice } from '../data/menu'

export function ProductCard({ product }: { product: Product }) {
  return (
    <article className="group overflow-hidden rounded-3xl bg-warm shadow-card ring-1 ring-brown-deep/5 transition duration-300 md:hover:-translate-y-1">
      <div className="relative overflow-hidden">
        <img
          src={`/images/products/${product.image}`}
          alt={product.name}
          loading="lazy"
          className="aspect-[16/10] w-full object-cover transition duration-700 md:group-hover:scale-[1.04]"
        />
        {product.tag && (
          <span className="absolute left-3 top-3 rounded-full bg-warm/95 px-3 py-1 text-[11px] font-medium uppercase tracking-[0.14em] text-burgundy shadow-sm">
            {product.tag}
          </span>
        )}
      </div>
      <div className="p-5">
        <div className="flex items-start justify-between gap-4">
          <h3 className="font-serif text-[22px] font-bold leading-tight text-brown-deep">{product.name}</h3>
          <span className="shrink-0 pt-0.5 text-[19px] font-semibold text-burgundy">{formatPrice(product.price)}</span>
        </div>
        <p className="mt-2 text-[15px] leading-relaxed text-brown-deep/70">{product.description}</p>
      </div>
    </article>
  )
}

/** Compact list-style row for items without a photo */
export function ProductRow({ product }: { product: Product }) {
  return (
    <li className="flex items-start justify-between gap-4 py-4">
      <div className="min-w-0">
        <h3 className="font-serif text-[19px] font-semibold leading-snug text-brown-deep">{product.name}</h3>
        <p className="mt-1 text-[14.5px] leading-relaxed text-brown-deep/65">{product.description}</p>
      </div>
      <span className="shrink-0 pt-0.5 text-[17px] font-semibold text-burgundy">{formatPrice(product.price)}</span>
    </li>
  )
}

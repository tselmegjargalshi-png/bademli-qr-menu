import type { ReactNode } from 'react'
import { business } from '../data/menu'
import { GlobeIcon, InstagramIcon, PhoneIcon, PinIcon } from './Icons'

function Item({ icon, label, value, href }: { icon: ReactNode; label: string; value: string; href: string }) {
  return (
    <a
      href={href}
      className="flex min-h-[64px] items-center gap-4 rounded-2xl bg-warm/80 px-5 py-3 ring-1 ring-beige/70 transition hover:bg-warm"
    >
      <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-burgundy/10 text-burgundy">{icon}</span>
      <span className="min-w-0">
        <span className="block text-[11px] uppercase tracking-[0.2em] text-brown-deep/55">{label}</span>
        <span className="block truncate text-[16px] font-medium text-brown-deep">{value}</span>
      </span>
    </a>
  )
}

export default function ContactSection() {
  return (
    <section id="iletisim" aria-labelledby="h-iletisim" className="mx-auto mt-14 max-w-6xl scroll-mt-20 px-5 sm:px-8">
      <h2 id="h-iletisim" className="font-serif text-[30px] font-bold text-brown-deep">İletişim</h2>
      <p className="mt-1 text-[15px] text-brown-deep/70">Bizi ziyaret edin ya da arayın.</p>
      <div className="mt-5 grid gap-3 sm:grid-cols-2">
        <Item icon={<PhoneIcon />} label="Telefon" value={business.phone} href={business.phoneHref} />
        <Item icon={<PinIcon />} label="Konum" value={business.city} href="#iletisim" />
        <Item icon={<GlobeIcon />} label="Web" value={business.website} href={business.websiteHref} />
        <Item icon={<InstagramIcon />} label="Instagram" value="@bademlipastacafe" href={business.instagramHref} />
      </div>
    </section>
  )
}

import { useEffect, useRef } from 'react'
import type { Category, CategoryId } from '../types'

interface Props {
  categories: Category[]
  active: CategoryId
  onSelect: (id: CategoryId) => void
}

export default function CategoryNav({ categories, active, onSelect }: Props) {
  const scroller = useRef<HTMLDivElement>(null)

  // keep the active pill in view horizontally (without moving the page)
  useEffect(() => {
    const el = scroller.current?.querySelector<HTMLElement>(`[data-id="${active}"]`)
    const box = scroller.current
    if (!el || !box) return
    box.scrollTo({ left: el.offsetLeft - box.clientWidth / 2 + el.clientWidth / 2, behavior: 'smooth' })
  }, [active])

  return (
    <nav
      aria-label="Menü kategorileri"
      className="sticky top-0 z-30 border-b border-beige/60 bg-cream/90 backdrop-blur-md"
    >
      <div ref={scroller} className="no-scrollbar mx-auto flex max-w-6xl gap-2 overflow-x-auto px-5 py-3 sm:px-8">
        {categories.map((c) => {
          const on = c.id === active
          return (
            <button
              key={c.id}
              data-id={c.id}
              onClick={() => onSelect(c.id)}
              aria-current={on ? 'true' : undefined}
              className={`h-11 shrink-0 rounded-full px-5 text-[14px] font-medium tracking-wide transition ${
                on
                  ? 'bg-burgundy text-warm shadow-card'
                  : 'border border-beige bg-warm/70 text-brown-deep hover:bg-warm'
              }`}
            >
              {c.short}
            </button>
          )
        })}
      </div>
    </nav>
  )
}

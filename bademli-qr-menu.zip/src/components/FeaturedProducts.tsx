import type { Product } from '../types'
import { formatPrice } from '../data/menu'

export default function FeaturedProducts({ items }: { items: Product[] }) {
  return (
    <section id="cok-sevilenler" aria-labelledby="h-cok-sevilenler" className="scroll-mt-20 pt-8">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <p className="text-[11px] font-medium uppercase tracking-[0.3em] text-burgundy">Seçkin Lezzetler</p>
        <h2 id="h-cok-sevilenler" className="mt-2 font-serif text-[32px] font-bold text-brown-deep">Çok Sevilenler</h2>
        <p className="mt-1 text-[15px] text-brown-deep/70">Misafirlerimizin en çok tercih ettiği lezzetler.</p>
      </div>

      <div className="no-scrollbar mt-5 flex snap-x snap-mandatory gap-4 overflow-x-auto px-5 pb-6 sm:px-8 md:mx-auto md:max-w-6xl">
        {items.map((p) => (
          <article
            key={p.id}
            className="w-[80vw] max-w-[340px] shrink-0 snap-start overflow-hidden rounded-3xl bg-warm shadow-card ring-1 ring-brown-deep/5"
          >
            <img src={`/images/products/${p.image}`} alt={p.name} loading="lazy" className="aspect-[4/3] w-full object-cover" />
            <div className="p-5">
              <div className="flex items-start justify-between gap-3">
                <h3 className="font-serif text-[21px] font-bold leading-tight text-brown-deep">{p.name}</h3>
                <span className="shrink-0 text-[19px] font-semibold text-burgundy">{formatPrice(p.price)}</span>
              </div>
              <p className="mt-2 line-clamp-3 text-[14.5px] leading-relaxed text-brown-deep/70">{p.description}</p>
            </div>
          </article>
        ))}
      </div>
    </section>
  )
}

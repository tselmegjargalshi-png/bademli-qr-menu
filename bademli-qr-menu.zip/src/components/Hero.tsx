import { ArrowDownIcon } from './Icons'
import { business } from '../data/menu'

interface Props { onExplore: () => void }

export default function Hero({ onExplore }: Props) {
  return (
    <section id="top" className="mx-auto max-w-6xl px-5 pb-6 pt-6 sm:px-8 md:grid md:grid-cols-2 md:items-center md:gap-12 md:pt-10">
      <div>
        <p className="text-[11px] font-medium uppercase tracking-[0.32em] text-burgundy">{business.tagline}</p>
        <h1 className="mt-3 font-serif text-[40px] font-bold leading-[1.05] text-brown-deep sm:text-5xl md:text-6xl">
          Günün En <br className="hidden sm:block" />
          <span className="italic text-brown-choc">Tatlı</span> Molası
        </h1>
        <p className="mt-4 max-w-md text-[16px] leading-relaxed text-brown-deep/75">
          Taze tatlar, özenle hazırlanmış tatlılar ve kahve eşliğinde keyifli bir mola.
        </p>
        <button
          onClick={onExplore}
          className="mt-6 inline-flex h-12 items-center gap-2 rounded-full bg-burgundy px-7 text-[15px] font-medium tracking-wide text-warm shadow-card transition hover:bg-[#7a171d] active:scale-[0.98]"
        >
          Menüyü Keşfet
          <ArrowDownIcon width={18} height={18} />
        </button>
      </div>

      <div className="relative mt-8 md:mt-0">
        <div className="overflow-hidden rounded-[28px] shadow-card ring-1 ring-brown-deep/10">
          <img
            src="/images/products/lotuslu-cheesecake.jpg"
            alt="Lotuslu cheesecake dilimi"
            className="aspect-[4/3] w-full object-cover"
            fetchPriority="high"
          />
        </div>
        <div className="absolute -bottom-4 left-4 rounded-full bg-warm px-4 py-2 text-[12px] font-medium tracking-wide text-brown-choc shadow-card ring-1 ring-beige">
          {business.city}
        </div>
      </div>
    </section>
  )
}
